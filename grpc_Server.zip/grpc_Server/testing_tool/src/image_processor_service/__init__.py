"""Image processor microservice package."""
